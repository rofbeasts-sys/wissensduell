/* ============================================================================
 * ERFOLGE - gemeinsames Modul fuer Client (Browser) UND Server (Node).
 *
 * Eine einzige Definition aller Erfolge + die Regeln, wie Ereignisse (Events)
 * den Fortschritt veraendern. Der Server nutzt dieselbe Datei, um beim
 * Speichern eines Kontos NUR plausible Staende zu uebernehmen:
 *   - Zaehler duerfen nie sinken, Sonderfelder werden begrenzt,
 *   - "freigeschaltet" wird IMMER aus den Zaehlern neu berechnet (ein Client
 *     kann also keinen Erfolg direkt als erledigt melden).
 * Wichtig/ehrlich: Die Zaehler selbst meldet der Client (Brain Test, Bot-Spiele
 * und Speed Math laufen nur im Browser). Ein Angreifer koennte also erfundene
 * Zaehlerstaende schicken. Was hier verhindert wird, ist nur der einfache
 * Weg ("unlocked":[...] direkt setzen) und unsinnige Werte.
 * ========================================================================== */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.Achv = factory();
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  const KLASSEN = 10;              // Anzahl Brain-Test-Klassen
  const MAIN_TEST_PASS_PCT = 0.8;  // Haupttest bestanden ab 80 %
  const FAST_SECONDS = 60;         // "in 1 Minute"

  const CATEGORIES = [
    { id: "braintest", title: "Brain Test", icon: "🧠" },
    { id: "ordering",  title: "Drag and Drop", icon: "📊" },
    { id: "mow",       title: "Higher or Lower", icon: "⚖️" },
    { id: "blitz",     title: "Quick-Fire", icon: "⚡" },
    { id: "slf",       title: "Scattergories", icon: "✏️" },
    { id: "biology",   title: "Biologie", icon: "🧬" },
    { id: "ttt",       title: "Tic Tac Toe", icon: "⭕" },
    { id: "chess",     title: "Schach", icon: "♟️" },
    { id: "four",      title: "4 gewinnt", icon: "🔴" },
    { id: "mill",      title: "Mühle", icon: "⚪" },
    { id: "dame",      title: "Dame", icon: "♛" },
    { id: "daily",     title: "Daily Puzzles", icon: "🧩" },
    { id: "chem",      title: "Brainchimie", icon: "⚗️" },
    { id: "vocab",     title: "Vokabeln", icon: "📚" },
    { id: "shop",      title: "Shop", icon: "🛒" },
    { id: "general",   title: "Allgemein", icon: "🌟" }
  ];
  // Englische Kategorie-Titel (fuer die Anzeige UND fuer die automatisch
  // generierten cat_*-Erfolgstitel/-beschreibungen weiter unten).
  const CATEGORY_TITLES_EN = {
    braintest: "Brain Test", ordering: "Drag and Drop", mow: "Higher or Lower", blitz: "Quick-Fire",
    slf: "Scattergories", biology: "Biology", ttt: "Tic Tac Toe", general: "General",
    chem: "Brain Chemistry", vocab: "Vocabulary", shop: "Shop",
    chess: "Chess", four: "Connect Four", mill: "Nine Men's Morris", dame: "Checkers", daily: "Daily Puzzles"
  };

  const CHEM_TOTAL = 258, VOC_TOTAL = 35;
  const sum = (arr) => arr.reduce((a, b) => a + (b ? 1 : 0), 0);
  const P = (fn, target) => (s) => [Math.min(fn(s), target), target]; // Fortschritt gedeckelt auf das Ziel

  const BASE_DEFS = [
    // ---------------------------------------------------------------- Brain Test
    { id: "bt_all_classes", cat: "braintest", icon: "🎓", title: "Alle Klassen geschafft", desc: "Schaffe jede der 10 Klassen (Haupttest bestanden).", progress: P(s => sum(s.bt.passed), KLASSEN) },
    { id: "bt_all_perfect", cat: "braintest", icon: "💯", title: "Makellos durch alle Klassen", desc: "Schaffe jede Klasse mit 100 Prozent.", progress: P(s => sum(s.bt.perfect), KLASSEN) },
    { id: "bt_perfect_5",   cat: "braintest", icon: "🔁", title: "Fünfmal perfekt", desc: "Mach den Haupttest 5-mal mit 100 Prozent.", progress: P(s => s.bt.perfectRuns, 5) },
    { id: "bt_all_fast",    cat: "braintest", icon: "⏱️", title: "Schnellster Kopf", desc: "Schaffe jede Klasse in 1 Minute.", progress: P(s => sum(s.bt.fast), KLASSEN) },
    // ---------------------------------------------------------------- Einordnen
    { id: "ord_complete", cat: "ordering", icon: "✅", title: "Runde komplett", desc: "Schaffe eine Drag-and-Drop-Runde komplett.", progress: P(s => s.ord.completed, 1) },
    { id: "ord_flawless", cat: "ordering", icon: "❤️", title: "Ohne Verlust", desc: "Schaffe eine Drag-and-Drop-Runde, ohne ein Leben zu verlieren.", progress: P(s => s.ord.flawless, 1) },
    // ---------------------------------------------------------------- Mehr oder Weniger
    { id: "mow_complete", cat: "mow", icon: "✅", title: "Runde komplett", desc: "Schaffe eine Higher-or-Lower-Runde komplett.", progress: P(s => s.mow.completed, 1) },
    { id: "mow_flawless", cat: "mow", icon: "❤️", title: "Ohne Verlust", desc: "Schaffe eine Higher-or-Lower-Runde, ohne ein Leben zu verlieren.", progress: P(s => s.mow.flawless, 1) },
    // ---------------------------------------------------------------- Nenn's Blitz
    ...[10, 15, 20, 30, 50].map(n => ({ id: "blitz_" + n, cat: "blitz", icon: "⚡", title: "Blitz " + n, desc: "Schaffe " + n + " gültige Antworten in einer Quick-Fire-Runde.", progress: P(s => s.blitz.best, n) })),
    // ---------------------------------------------------------------- Stadt Land Fluss
    { id: "slf_all_fields", cat: "slf", icon: "📝", title: "Alle Felder", desc: "Schreibe in jedes Feld etwas.", progress: P(s => s.slf.allFilled, 1) },
    { id: "slf_first_1",    cat: "slf", icon: "🥇", title: "Schnellster Stift", desc: "Sei in einer Mehrspielerrunde als Erste/r mit allen Feldern fertig.", progress: P(s => s.slf.firstFull, 1) },
    { id: "slf_first_50",   cat: "slf", icon: "🏅", title: "Schnellster Stift ×50", desc: "Sei 50-mal als Erste/r mit allen Feldern fertig.", progress: P(s => s.slf.firstFull, 50) },
    // ---------------------------------------------------------------- Tic Tac Toe
    { id: "ttt_all_belts",  cat: "ttt", icon: "🥋", title: "Alle Gürtel", desc: "Gewinne alle Gürtel (bis zum Meister).", progress: P(s => s.ttt.maxRank, 6) },
    { id: "ttt_win3_100",   cat: "ttt", icon: "⚡", title: "Blitzsieger", desc: "Gewinne 100-mal in 3 Zügen.", progress: P(s => s.ttt.win3, 100) },
    { id: "ttt_quantum_100", cat: "ttt", icon: "⚛️", title: "Quantum-Meister", desc: "Gewinne 100-mal im Quantum-Modus.", progress: P(s => s.ttt.quantumWins, 100) },
    { id: "ttt_quizmix_100", cat: "ttt", icon: "🧩", title: "QuizMix-Meister", desc: "Gewinne 100-mal im QuizMix.", progress: P(s => s.ttt.quizmixWins, 100) },
    { id: "ttt_quizmix_3",  cat: "ttt", icon: "🚀", title: "QuizMix-Blitz", desc: "Gewinne QuizMix in 3 Zügen.", progress: P(s => s.ttt.quizmix3, 1) },
    { id: "ttt_quizmix_3_perfect", cat: "ttt", icon: "🎯", title: "QuizMix-Perfektion", desc: "Gewinne QuizMix in den ersten 3 Runden und beantworte alle Fragen richtig.", progress: P(s => s.ttt.quizmix3Perfect, 1) },
    // ---------------------------------------------------------------- Allgemein
    ...[[10, "10"], [100, "100"], [1000, "1.000"], [10000, "10.000"], [100000, "100.000"], [1000000, "1 Million"]].map(([n, label], i) => ({
      id: "gen_" + n, cat: "general", icon: ["🌱", "🌿", "🌳", "🏆", "👑", "💎"][i], title: label + " richtige Antworten",
      desc: "Beantworte " + label + " Wissenstest-Fragen und Zahlenaufgaben richtig.", progress: P(s => s.gen.correct, n)
    })),
    // ---------------------------------------------------------------- eigene Ideen (siehe erfolg-ideen.md)
    { id: "ttt_unbeatable", cat: "ttt", icon: "🛡️", title: "Unbezwingbar", desc: "Spiele gegen den Meister-Bot unentschieden.", progress: P(s => s.ttt.meisterDraws, 1) },
    { id: "ord_mow_perfect_10", cat: "ordering", icon: "🌟", title: "Perfektionist", desc: "Schaffe 10 Runden (Drag and Drop oder Higher or Lower) ohne ein Leben zu verlieren.", progress: P(s => s.ord.flawless + s.mow.flawless, 10) },
    ...[[100, "100"], [500, "500"], [1000, "1.000"]].map(([n, label], i) => ({
      id: "blitz_total_" + n, cat: "blitz", icon: ["📣", "📯", "🎺"][i], title: "Vielnenner " + label,
      desc: "Sammle insgesamt " + label + " gültige Antworten in Quick-Fire.", progress: P(s => s.blitz.total, n)
    })),
    { id: "slf_unique_100", cat: "slf", icon: "💡", title: "Einzigartig", desc: "Gib 100-mal eine Antwort ab, die sonst niemand hatte (20 Punkte).", progress: P(s => s.slf.unique, 100) },
    ...[[10, "10"], [25, "25"], [50, "50"], [75, "75"], [100, "100"]].map(([n, label], i) => ({
      id: "sm_level_" + n, cat: "general", icon: ["🥾", "🏔️", "🚩", "🪂", "🚀"][i], title: "Speed-Math-Level " + label,
      desc: "Erreiche Level " + label + " im Speed-Math-Meilenstein-Modus.", progress: P(s => s.sm.level, n)
    })),
    // ---------------------------------------------------------------- Biologie
    ...[[3, "3"], [8, "8"], [14, "14"], [18, "18 (alle)"]].map(([n, label], i) => ({
      id: "bio_topics_" + n, cat: "biology", icon: ["🔬", "🩻", "🧪", "🏅"][i], title: label === "18 (alle)" ? "Biologie-Expertin/Experte" : label + " Themen erkundet",
      desc: label === "18 (alle)" ? "Schließe alle 18 Biologie-Themen (Körper + Sexualkunde) mindestens einmal ab." : "Schließe " + label + " verschiedene Biologie-Themen ab (egal wie oft).", progress: P(s => s.bio.topicsDone, n)
    })),
    ...[[1, "1"], [5, "5"], [12, "12"]].map(([n, label], i) => ({
      id: "bio_perfect_" + n, cat: "biology", icon: ["⭐", "🌟", "💯"][i], title: label === "1" ? "Erstes perfektes Thema" : label + " Themen fehlerfrei",
      desc: (label === "1" ? "Löse ein Biologie-Thema fehlerfrei (20/20)." : "Löse " + label + " Biologie-Themen fehlerfrei (jeweils 20/20)."), progress: P(s => s.bio.perfectCount, n)
    })),
    { id: "bio_sexualkunde_unlocked", cat: "biology", icon: "🌱", title: "Sexualkunde freigeschaltet", desc: "Löse alle 12 Körper-Themen fehlerfrei und schalte damit Sexualkunde frei.", progress: P(s => s.bio.sexualkundeUnlocked, 1) },
    ...[[3, "3"], [7, "7"], [30, "30"], [100, "100"]].map(([n, label], i) => ({
      id: "streak_" + n, cat: "general", icon: ["🔥", "📅", "🗓️", "🎇"][i], title: label + " Tage in Folge",
      desc: "Spiele " + label + " Kalendertage in Folge mindestens eine Runde.", progress: P(s => s.streak.longest, n)
    })),
    // ---------------------------------------------------------------- Schach / 4 gewinnt / Mühle / Dame / Daily
    { id: "chess_win_1",  cat: "chess", icon: "♟️", title: "Erster Sieg", desc: "Besiege den Schach-Bot einmal.", progress: P(s => s.chess.wins, 1) },
    { id: "chess_win_10", cat: "chess", icon: "♞", title: "Schachspieler", desc: "Gewinne 10 Partien gegen den Schach-Bot.", progress: P(s => s.chess.wins, 10) },
    { id: "chess_win_50", cat: "chess", icon: "♜", title: "Schachmeister", desc: "Gewinne 50 Partien gegen den Schach-Bot.", progress: P(s => s.chess.wins, 50) },
    { id: "chess_master", cat: "chess", icon: "👑", title: "Meister geschlagen", desc: "Besiege den Bot auf der Stufe Meister.", progress: P(s => s.chess.masterWins, 1) },
    { id: "chess_fast",   cat: "chess", icon: "⚡", title: "Blitzmatt", desc: "Gewinne eine Partie in höchstens 20 Zügen.", progress: P(s => s.chess.fast, 1) },
    { id: "chess_flawless", cat: "chess", icon: "🛡️", title: "Ohne Verlust", desc: "Gewinne eine Partie, ohne eine einzige Figur zu verlieren.", progress: P(s => s.chess.flawless, 1) },
    { id: "chess_games_25", cat: "chess", icon: "🎲", title: "Vielspieler", desc: "Spiele 25 Schachpartien.", progress: P(s => s.chess.games, 25) },
    { id: "four_win_1",  cat: "four", icon: "🔴", title: "Erste Vier", desc: "Gewinne ein Spiel 4 gewinnt.", progress: P(s => s.four.wins, 1) },
    { id: "four_win_10", cat: "four", icon: "🟡", title: "Vierer-Profi", desc: "Gewinne 10 Spiele 4 gewinnt.", progress: P(s => s.four.wins, 10) },
    { id: "four_win_50", cat: "four", icon: "🏆", title: "Vierer-Meister", desc: "Gewinne 50 Spiele 4 gewinnt.", progress: P(s => s.four.wins, 50) },
    { id: "four_hard",   cat: "four", icon: "😈", title: "Schwerer Gegner", desc: "Besiege den schweren Bot in 4 gewinnt.", progress: P(s => s.four.hardWins, 1) },
    { id: "four_quick",  cat: "four", icon: "🚀", title: "Blitzvier", desc: "Gewinne mit nur 4 eigenen Steinen.", progress: P(s => s.four.quick, 1) },
    { id: "four_diag",   cat: "four", icon: "↗️", title: "Diagonal", desc: "Gewinne mit einer diagonalen Vierer-Reihe.", progress: P(s => s.four.diag, 1) },
    { id: "four_online", cat: "four", icon: "🌐", title: "Online-Sieger", desc: "Gewinne 4 gewinnt gegen einen echten Gegner.", progress: P(s => s.four.online, 1) },
    { id: "mill_win_1",  cat: "mill", icon: "⚪", title: "Erste Mühle", desc: "Gewinne ein Mühle-Spiel.", progress: P(s => s.mill.wins, 1) },
    { id: "mill_win_10", cat: "mill", icon: "⚫", title: "Mühle-Profi", desc: "Gewinne 10 Mühle-Spiele.", progress: P(s => s.mill.wins, 10) },
    { id: "mill_win_25", cat: "mill", icon: "🏆", title: "Mühle-Meister", desc: "Gewinne 25 Mühle-Spiele.", progress: P(s => s.mill.wins, 25) },
    { id: "mill_hard",   cat: "mill", icon: "😈", title: "Schwerer Gegner", desc: "Besiege den schweren Bot in Mühle.", progress: P(s => s.mill.hardWins, 1) },
    { id: "mill_mills_25", cat: "mill", icon: "⚙️", title: "Mühlenbauer", desc: "Schließe insgesamt 25 Mühlen.", progress: P(s => s.mill.mills, 25) },
    { id: "mill_online", cat: "mill", icon: "🌐", title: "Online-Sieger", desc: "Gewinne Mühle gegen einen echten Gegner.", progress: P(s => s.mill.online, 1) },
    { id: "dame_win_1",  cat: "dame", icon: "♛", title: "Erster Sieg", desc: "Gewinne ein Spiel Dame.", progress: P(s => s.dame.wins, 1) },
    { id: "dame_win_10", cat: "dame", icon: "👸", title: "Dame-Profi", desc: "Gewinne 10 Spiele Dame.", progress: P(s => s.dame.wins, 10) },
    { id: "dame_win_25", cat: "dame", icon: "🏆", title: "Dame-Meisterin", desc: "Gewinne 25 Spiele Dame.", progress: P(s => s.dame.wins, 25) },
    { id: "dame_hard",   cat: "dame", icon: "😈", title: "Schwerer Gegner", desc: "Besiege den schweren Bot in Dame.", progress: P(s => s.dame.hardWins, 1) },
    { id: "dame_online", cat: "dame", icon: "🌐", title: "Online-Siegerin", desc: "Gewinne Dame gegen einen echten Gegner.", progress: P(s => s.dame.online, 1) },
    { id: "daily_1",      cat: "daily", icon: "🧩", title: "Erstes Rätsel", desc: "Löse ein Daily Puzzle.", progress: P(s => s.daily.solved, 1) },
    { id: "daily_10",     cat: "daily", icon: "📆", title: "Rätselfreund", desc: "Löse 10 Daily Puzzles.", progress: P(s => s.daily.solved, 10) },
    { id: "daily_50",     cat: "daily", icon: "🧠", title: "Rätselprofi", desc: "Löse 50 Daily Puzzles.", progress: P(s => s.daily.solved, 50) },
    { id: "daily_sudoku", cat: "daily", icon: "🔢", title: "Sudoku-Löser", desc: "Löse ein Daily-Sudoku.", progress: P(s => s.daily.sudoku, 1) },
    { id: "daily_cw",     cat: "daily", icon: "✏️", title: "Kreuzworträtsler", desc: "Löse ein Daily-Kreuzworträtsel.", progress: P(s => s.daily.cw, 1) },
    { id: "daily_all_types", cat: "daily", icon: "🎯", title: "Allrounder", desc: "Löse jede Rätselart (Sudoku, Kreuzworträtsel, Wortsuche, Wortnetz) mindestens einmal.", progress: P(s => (s.daily.sudoku > 0) + (s.daily.cw > 0) + (s.daily.ws > 0) + (s.daily.wv > 0), 4) },
    { id: "chem_first", cat: "chem", icon: "🧪", title: "Erste Mischung", desc: "Kombiniere zwei Elemente zu etwas Neuem.", progress: P(s => s.chem.found - 3, 1) },
    { id: "chem_25",  cat: "chem", icon: "⚗️", title: "Kleines Labor", desc: "Entdecke 25 Elemente.", progress: P(s => s.chem.found, 25) },
    { id: "chem_50",  cat: "chem", icon: "🔬", title: "Hobby-Chemiker", desc: "Entdecke 50 Elemente.", progress: P(s => s.chem.found, 50) },
    { id: "chem_100", cat: "chem", icon: "🧬", title: "Forscher", desc: "Entdecke 100 Elemente.", progress: P(s => s.chem.found, 100) },
    { id: "chem_200", cat: "chem", icon: "🌋", title: "Alchemist", desc: "Entdecke 200 Elemente.", progress: P(s => s.chem.found, 200) },
    { id: "chem_all", cat: "chem", icon: "👑", title: "Meister der Elemente", desc: "Entdecke alle Elemente.", progress: P(s => s.chem.found, CHEM_TOTAL) },
    { id: "chem_help", cat: "chem", icon: "💡", title: "Hilfe geholt", desc: "Kaufe in Brainchimie einen Tipp.", progress: P(s => s.chem.helps, 1) },
    { id: "voc_learn_1",  cat: "vocab", icon: "📖", title: "Erstes Thema", desc: "Lerne ein Vokabel-Thema.", progress: P(s => s.vocab.learned, 1) },
    { id: "voc_learn_10", cat: "vocab", icon: "📚", title: "Wortsammler", desc: "Lerne 10 Vokabel-Themen.", progress: P(s => s.vocab.learned, 10) },
    { id: "voc_learn_all", cat: "vocab", icon: "🎓", title: "Alles gelernt", desc: "Lerne alle Vokabel-Themen.", progress: P(s => s.vocab.learned, VOC_TOTAL) },
    { id: "voc_exam_1",  cat: "vocab", icon: "✅", title: "Test bestanden", desc: "Schaffe einen Übungstest mit 100 Prozent.", progress: P(s => s.vocab.exam, 1) },
    { id: "voc_exam_10", cat: "vocab", icon: "💯", title: "Testprofi", desc: "Schaffe 10 Übungstests mit 100 Prozent.", progress: P(s => s.vocab.exam, 10) },
    { id: "voc_talk_1",  cat: "vocab", icon: "🎩", title: "Gespräch mit dem Professor", desc: "Schließe ein Gespräch mit dem Professor ab.", progress: P(s => s.vocab.talk, 1) },
    { id: "voc_star_1",  cat: "vocab", icon: "⭐", title: "Drei Sterne", desc: "Hole in einem Thema alle 3 Sterne.", progress: P(s => s.vocab.stars3, 1) },
    { id: "voc_star_10", cat: "vocab", icon: "🌟", title: "Sternesammler", desc: "Hole in 10 Themen alle 3 Sterne.", progress: P(s => s.vocab.stars3, 10) },
    { id: "voc_star_all", cat: "vocab", icon: "👑", title: "Vokabel-Meister", desc: "Hole in allen Themen alle 3 Sterne.", progress: P(s => s.vocab.stars3, VOC_TOTAL) },
    { id: "voc_blitz_100", cat: "vocab", icon: "⚡", title: "Match-Blitz 100", desc: "Erreiche im Match-Blitz 100 Punkte.", progress: P(s => s.vocab.blitzBest, 100) },
    { id: "voc_blitz_300", cat: "vocab", icon: "🚀", title: "Match-Blitz 300", desc: "Erreiche im Match-Blitz 300 Punkte.", progress: P(s => s.vocab.blitzBest, 300) },
    { id: "shop_1",  cat: "shop", icon: "🛍️", title: "Erster Einkauf", desc: "Kaufe etwas im Shop.", progress: P(s => s.shop.buys, 1) },
    { id: "shop_5",  cat: "shop", icon: "🧺", title: "Stammkunde", desc: "Kaufe 5-mal im Shop ein.", progress: P(s => s.shop.buys, 5) },
    { id: "shop_25", cat: "shop", icon: "💰", title: "Großeinkauf", desc: "Kaufe 25-mal im Shop ein.", progress: P(s => s.shop.buys, 25) },
    { id: "shop_slot", cat: "shop", icon: "🎒", title: "Mehr Platz", desc: "Kaufe Zusatz-Speicher.", progress: P(s => s.shop.slots, 1) },
    { id: "shop_boost", cat: "shop", icon: "🍎", title: "Booster-Fan", desc: "Kaufe einen Booster.", progress: P(s => s.shop.boosters, 1) },
    { id: "shop_heart", cat: "shop", icon: "❤️", title: "Herzenssache", desc: "Fülle ein Herz im Shop auf.", progress: P(s => s.shop.hearts, 1) },
    { id: "shop_all", cat: "shop", icon: "🏅", title: "Alles probiert", desc: "Kaufe Speicher, Booster und ein Herz.", progress: P(s => (s.shop.slots > 0) + (s.shop.boosters > 0) + (s.shop.hearts > 0), 3) },
    { id: "daily_streak_7", cat: "daily", icon: "🔥", title: "7 Rätseltage in Folge", desc: "Löse an 7 Kalendertagen in Folge ein Daily Puzzle.", progress: P(s => s.daily.longest, 7) }
  ];
  // Kategorie-Abschluss: einmal je Kategorie, zaehlt nur die "richtigen" Erfolge dieser
  // Kategorie (nicht sich selbst und nicht die Sammel-Erfolge unten).
  const CATEGORY_DEFS = CATEGORIES.map(c => ({
    id: "cat_" + c.id, cat: c.id, icon: "🏵️", title: c.title + " gemeistert",
    desc: "Schalte alle Erfolge in der Kategorie „" + c.title + "“ frei.",
    progress: (s) => { const list = BASE_DEFS.filter(d => d.cat === c.id); return [list.filter(d => s.unlocked[d.id]).length, list.length]; }
  }));
  // "Zaehlbare" Erfolge fuer die Sammel-Erfolge: alle BASE_DEFS + die Kategorie-Erfolge,
  // aber NICHT die Sammel-Erfolge selbst (sonst zaehlten sie sich mit).
  const COUNTABLE_DEFS = BASE_DEFS.concat(CATEGORY_DEFS);
  const countDone = (s) => COUNTABLE_DEFS.filter(d => s.unlocked[d.id]).length;
  const COLLECTOR_DEFS = [
    { id: "collector_5", cat: "general", icon: "🧩", title: "Sammler", desc: "Schalte 5 Erfolge frei.", progress: (s) => [Math.min(countDone(s), 5), 5] },
    { id: "collector_15", cat: "general", icon: "🎖️", title: "Vielseitig", desc: "Schalte 15 Erfolge frei.", progress: (s) => [Math.min(countDone(s), 15), 15] },
    { id: "collector_all", cat: "general", icon: "👑", title: "Vollständig", desc: "Schalte alle anderen Erfolge frei.", progress: (s) => [Math.min(countDone(s), COUNTABLE_DEFS.length), COUNTABLE_DEFS.length] }
  ];
  // Reihenfolge wichtig: BASE zuerst, dann Kategorie (braucht BASE), dann Sammler (braucht beide) -
  // evaluate() geht die Liste einmal in dieser Reihenfolge durch und aktualisiert state.unlocked
  // dabei laufend, so werden neu erfuellte Kategorie-/Sammel-Erfolge in DERSELBEN Runde erkannt.
  const DEFS = BASE_DEFS.concat(CATEGORY_DEFS, COLLECTOR_DEFS);
  const BY_ID = Object.fromEntries(DEFS.map(d => [d.id, d]));

  // ------------------------------------------------------------- Uebersetzung
  // Separate Tabelle statt die DEFS-Struktur umzubauen (dort sind viele
  // Eintraege per .map() aus Zahlenlisten generiert - eine zweisprachige
  // {de,en}-Struktur direkt dort haette den ganzen Aufbau unuebersichtlich
  // gemacht). TEXT_EN[id] = {title, desc}; fehlt ein Eintrag, faellt die
  // Anzeige automatisch auf Deutsch zurueck (siehe getTitle/getDesc unten).
  const TEXT_EN = {
    bt_all_classes: { title: "All classes done", desc: "Pass every one of the 10 classes (main test passed)." },
    bt_all_perfect: { title: "Flawless through every class", desc: "Pass every class with 100 percent." },
    bt_perfect_5: { title: "Five times perfect", desc: "Score 100 percent on the main test 5 times." },
    bt_all_fast: { title: "Fastest mind", desc: "Pass every class within 1 minute." },
    ord_complete: { title: "Round complete", desc: "Complete a full round of Drag and Drop." },
    ord_flawless: { title: "No losses", desc: "Complete a round of Drag and Drop without losing a life." },
    mow_complete: { title: "Round complete", desc: "Complete a full round of Higher or Lower." },
    mow_flawless: { title: "No losses", desc: "Complete a round of Higher or Lower without losing a life." },
    blitz_10: { title: "Quick 10", desc: "Get 10 valid answers in one round of Quick-Fire." },
    blitz_15: { title: "Quick 15", desc: "Get 15 valid answers in one round of Quick-Fire." },
    blitz_20: { title: "Quick 20", desc: "Get 20 valid answers in one round of Quick-Fire." },
    blitz_30: { title: "Quick 30", desc: "Get 30 valid answers in one round of Quick-Fire." },
    blitz_50: { title: "Quick 50", desc: "Get 50 valid answers in one round of Quick-Fire." },
    slf_all_fields: { title: "Every field", desc: "Write something in every field." },
    slf_first_1: { title: "Fastest pen", desc: "Be the first to finish all fields in a multiplayer round." },
    slf_first_50: { title: "Fastest pen x50", desc: "Be the first to finish all fields 50 times." },
    ttt_all_belts: { title: "Every belt", desc: "Win every belt, all the way to Master." },
    ttt_win3_100: { title: "Lightning winner", desc: "Win in 3 moves, 100 times." },
    ttt_quantum_100: { title: "Quantum master", desc: "Win 100 games in Quantum mode." },
    ttt_quizmix_100: { title: "QuizMix master", desc: "Win 100 games of QuizMix." },
    ttt_quizmix_3: { title: "QuizMix blitz", desc: "Win a game of QuizMix in 3 moves." },
    ttt_quizmix_3_perfect: { title: "QuizMix perfection", desc: "Win QuizMix in the first 3 rounds and answer every question correctly." },
    gen_10: { title: "10 correct answers", desc: "Answer 10 questions correctly across Brain Test and number challenges." },
    gen_100: { title: "100 correct answers", desc: "Answer 100 questions correctly across Brain Test and number challenges." },
    gen_1000: { title: "1,000 correct answers", desc: "Answer 1,000 questions correctly across Brain Test and number challenges." },
    gen_10000: { title: "10,000 correct answers", desc: "Answer 10,000 questions correctly across Brain Test and number challenges." },
    gen_100000: { title: "100,000 correct answers", desc: "Answer 100,000 questions correctly across Brain Test and number challenges." },
    gen_1000000: { title: "1 million correct answers", desc: "Answer 1 million questions correctly across Brain Test and number challenges." },
    ttt_unbeatable: { title: "Unbeatable", desc: "Draw a game against the Master bot." },
    ord_mow_perfect_10: { title: "Perfectionist", desc: "Complete 10 rounds (Drag and Drop or Higher or Lower) without losing a life." },
    blitz_total_100: { title: "Prolific namer 100", desc: "Collect a total of 100 valid answers in Quick-Fire." },
    blitz_total_500: { title: "Prolific namer 500", desc: "Collect a total of 500 valid answers in Quick-Fire." },
    blitz_total_1000: { title: "Prolific namer 1,000", desc: "Collect a total of 1,000 valid answers in Quick-Fire." },
    slf_unique_100: { title: "One of a kind", desc: "Submit an answer nobody else had, 100 times (20 points)." },
    sm_level_10: { title: "Speed Math level 10", desc: "Reach level 10 in Speed Math milestone mode." },
    sm_level_25: { title: "Speed Math level 25", desc: "Reach level 25 in Speed Math milestone mode." },
    sm_level_50: { title: "Speed Math level 50", desc: "Reach level 50 in Speed Math milestone mode." },
    sm_level_75: { title: "Speed Math level 75", desc: "Reach level 75 in Speed Math milestone mode." },
    sm_level_100: { title: "Speed Math level 100", desc: "Reach level 100 in Speed Math milestone mode." },
    bio_topics_3: { title: "3 topics explored", desc: "Complete 3 different Biology topics (any number of times)." },
    bio_topics_8: { title: "8 topics explored", desc: "Complete 8 different Biology topics (any number of times)." },
    bio_topics_14: { title: "14 topics explored", desc: "Complete 14 different Biology topics (any number of times)." },
    bio_topics_18: { title: "Biology expert", desc: "Complete all 18 Biology topics (Body + Sex Ed) at least once." },
    bio_perfect_1: { title: "First flawless topic", desc: "Solve a Biology topic flawlessly (20/20)." },
    bio_perfect_5: { title: "5 flawless topics", desc: "Solve 5 Biology topics flawlessly (20/20 each)." },
    bio_perfect_12: { title: "12 flawless topics", desc: "Solve 12 Biology topics flawlessly (20/20 each)." },
    bio_sexualkunde_unlocked: { title: "Sex Ed unlocked", desc: "Solve all 12 Body topics flawlessly to unlock Sex Ed." },
    streak_3: { title: "3 days in a row", desc: "Play at least one round on 3 calendar days in a row." },
    streak_7: { title: "7 days in a row", desc: "Play at least one round on 7 calendar days in a row." },
    streak_30: { title: "30 days in a row", desc: "Play at least one round on 30 calendar days in a row." },
    streak_100: { title: "100 days in a row", desc: "Play at least one round on 100 calendar days in a row." },
    chess_win_1: { title: "First win", desc: "Beat the chess bot once." },
    chess_win_10: { title: "Chess player", desc: "Win 10 games against the chess bot." },
    chess_win_50: { title: "Chess master", desc: "Win 50 games against the chess bot." },
    chess_master: { title: "Master defeated", desc: "Beat the bot on Master level." },
    chess_fast: { title: "Lightning mate", desc: "Win a game in 20 moves or fewer." },
    chess_flawless: { title: "No losses", desc: "Win a game without losing a single piece." },
    chess_games_25: { title: "Regular", desc: "Play 25 chess games." },
    four_win_1: { title: "First four", desc: "Win a game of Connect Four." },
    four_win_10: { title: "Connect Four pro", desc: "Win 10 games of Connect Four." },
    four_win_50: { title: "Connect Four master", desc: "Win 50 games of Connect Four." },
    four_hard: { title: "Tough opponent", desc: "Beat the hard bot in Connect Four." },
    four_quick: { title: "Lightning four", desc: "Win with only 4 of your own discs." },
    four_diag: { title: "Diagonal", desc: "Win with a diagonal row of four." },
    four_online: { title: "Online winner", desc: "Win Connect Four against a real opponent." },
    mill_win_1: { title: "First mill", desc: "Win a game of Nine Men's Morris." },
    mill_win_10: { title: "Morris pro", desc: "Win 10 games of Nine Men's Morris." },
    mill_win_25: { title: "Morris master", desc: "Win 25 games of Nine Men's Morris." },
    mill_hard: { title: "Tough opponent", desc: "Beat the hard bot in Nine Men's Morris." },
    mill_mills_25: { title: "Mill builder", desc: "Close 25 mills in total." },
    mill_online: { title: "Online winner", desc: "Win Nine Men's Morris against a real opponent." },
    dame_win_1: { title: "First win", desc: "Win a game of Checkers." },
    dame_win_10: { title: "Checkers pro", desc: "Win 10 games of Checkers." },
    dame_win_25: { title: "Checkers master", desc: "Win 25 games of Checkers." },
    dame_hard: { title: "Tough opponent", desc: "Beat the hard bot in Checkers." },
    dame_online: { title: "Online winner", desc: "Win Checkers against a real opponent." },
    daily_1: { title: "First puzzle", desc: "Solve a Daily Puzzle." },
    daily_10: { title: "Puzzle fan", desc: "Solve 10 Daily Puzzles." },
    daily_50: { title: "Puzzle pro", desc: "Solve 50 Daily Puzzles." },
    daily_sudoku: { title: "Sudoku solver", desc: "Solve a Daily Sudoku." },
    daily_cw: { title: "Crossword solver", desc: "Solve a Daily Crossword." },
    daily_all_types: { title: "All-rounder", desc: "Solve every puzzle type (Sudoku, Crossword, Word Search, Word Web) at least once." },
    daily_streak_7: { title: "7 puzzle days in a row", desc: "Solve a Daily Puzzle on 7 calendar days in a row." },
    chem_first: { title: "First mix", desc: "Combine two elements into something new." },
    chem_25: { title: "Little lab", desc: "Discover 25 elements." },
    chem_50: { title: "Hobby chemist", desc: "Discover 50 elements." },
    chem_100: { title: "Researcher", desc: "Discover 100 elements." },
    chem_200: { title: "Alchemist", desc: "Discover 200 elements." },
    chem_all: { title: "Master of elements", desc: "Discover every element." },
    chem_help: { title: "Got a hint", desc: "Buy a hint in Brain Chemistry." },
    voc_learn_1: { title: "First topic", desc: "Learn a vocabulary topic." },
    voc_learn_10: { title: "Word collector", desc: "Learn 10 vocabulary topics." },
    voc_learn_all: { title: "Learned it all", desc: "Learn every vocabulary topic." },
    voc_exam_1: { title: "Test passed", desc: "Pass a practice test with 100 percent." },
    voc_exam_10: { title: "Test pro", desc: "Pass 10 practice tests with 100 percent." },
    voc_talk_1: { title: "Talk with the Professor", desc: "Finish a talk with the Professor." },
    voc_star_1: { title: "Three stars", desc: "Earn all 3 stars in a topic." },
    voc_star_10: { title: "Star collector", desc: "Earn all 3 stars in 10 topics." },
    voc_star_all: { title: "Vocabulary master", desc: "Earn all 3 stars in every topic." },
    voc_blitz_100: { title: "Match Blitz 100", desc: "Reach 100 points in Match Blitz." },
    voc_blitz_300: { title: "Match Blitz 300", desc: "Reach 300 points in Match Blitz." },
    shop_1: { title: "First purchase", desc: "Buy something in the shop." },
    shop_5: { title: "Regular", desc: "Shop 5 times." },
    shop_25: { title: "Big spender", desc: "Shop 25 times." },
    shop_slot: { title: "More room", desc: "Buy extra storage." },
    shop_boost: { title: "Booster fan", desc: "Buy a booster." },
    shop_heart: { title: "Matter of the heart", desc: "Refill a heart in the shop." },
    shop_all: { title: "Tried it all", desc: "Buy storage, a booster and a heart." },
    collector_5: { title: "Collector", desc: "Unlock 5 achievements." },
    collector_15: { title: "Well-rounded", desc: "Unlock 15 achievements." },
    collector_all: { title: "Complete", desc: "Unlock every other achievement." }
  };
  // cat_*-Erfolge werden automatisch aus CATEGORIES erzeugt - ihre englische
  // Uebersetzung deshalb hier ebenfalls automatisch aus CATEGORY_TITLES_EN
  // ableiten statt jede einzeln von Hand zu pflegen.
  CATEGORIES.forEach(c => {
    const en = CATEGORY_TITLES_EN[c.id] || c.title;
    TEXT_EN["cat_" + c.id] = { title: en + " mastered", desc: `Unlock every achievement in the "${en}" category.` };
  });
  function getTitle(id, lang) { return (lang === "en" && TEXT_EN[id] && TEXT_EN[id].title) || (BY_ID[id] && BY_ID[id].title) || ""; }
  function getDesc(id, lang) { return (lang === "en" && TEXT_EN[id] && TEXT_EN[id].desc) || (BY_ID[id] && BY_ID[id].desc) || ""; }
  function getCategoryTitle(catId, lang) { return (lang === "en" && CATEGORY_TITLES_EN[catId]) || (CATEGORIES.find(c => c.id === catId) || {}).title || ""; }

  // ------------------------------------------------------------------ Zustand
  const zeros = (n) => Array.from({ length: n }, () => 0);
  function newState() {
    return {
      v: 1,
      bt: { passed: zeros(KLASSEN), perfect: zeros(KLASSEN), fast: zeros(KLASSEN), perfectRuns: 0 },
      ord: { completed: 0, flawless: 0 },
      mow: { completed: 0, flawless: 0 },
      blitz: { best: 0, total: 0 },
      slf: { allFilled: 0, firstFull: 0, unique: 0 },
      ttt: { maxRank: 0, win3: 0, quantumWins: 0, quizmixWins: 0, quizmix3: 0, quizmix3Perfect: 0, meisterDraws: 0 },
      gen: { correct: 0 },
      sm: { level: 0 },
      bio: { topicsDone: 0, perfectCount: 0, sexualkundeUnlocked: 0 },
      streak: { current: 0, longest: 0, lastDate: null },
      chess: { wins: 0, masterWins: 0, fast: 0, flawless: 0, games: 0 },
      four: { wins: 0, hardWins: 0, quick: 0, diag: 0, online: 0 },
      mill: { wins: 0, hardWins: 0, mills: 0, online: 0 },
      dame: { wins: 0, hardWins: 0, online: 0 },
      party: { played: 0, wins: 0 },
      music: { played: 0, correct: 0 },
      daily: { solved: 0, sudoku: 0, cw: 0, ws: 0, wv: 0, current: 0, longest: 0, lastDate: null },
      chem: { found: 3, helps: 0 },
      vocab: { learned: 0, exam: 0, talk: 0, stars3: 0, blitzBest: 0 },
      shop: { buys: 0, slots: 0, boosters: 0, hearts: 0 },
      unlocked: {}
    };
  }
  const CAPS = { perfectRuns: 1e6, completed: 1e7, flawless: 1e7, best: 1000, total: 1e7, allFilled: 1e7, firstFull: 1e7, unique: 1e7,
    maxRank: 6, win3: 1e7, quantumWins: 1e7, quizmixWins: 1e7, quizmix3: 1e7, quizmix3Perfect: 1e7, meisterDraws: 1e6, correct: 1e9, level: 100, current: 1e5, longest: 1e5,
    topicsDone: 18, perfectCount: 18, found: 400, helps: 1e6, learned: 100, exam: 100, talk: 100, stars3: 100, blitzBest: 100000, buys: 1e7, slots: 1e7, boosters: 1e7, hearts: 1e7,
    wins: 1e7, masterWins: 1e7, fast: 1e7, flawless: 1e7, games: 1e7, hardWins: 1e7, quick: 1e7, diag: 1e7, online: 1e7, mills: 1e7, solved: 1e7, sudoku: 1e7, cw: 1e7, ws: 1e7, wv: 1e7, played: 1e7, correct: 1e9 };
  const num = (v, cap) => { v = Number(v); return Number.isFinite(v) && v > 0 ? Math.min(Math.floor(v), cap) : 0; };
  const flags = (a) => Array.from({ length: KLASSEN }, (_, i) => (Array.isArray(a) && a[i] ? 1 : 0));

  // Beliebige (auch fremde/kaputte) Daten -> gueltiger Zustand
  function normalize(raw) {
    const s = newState();
    if (!raw || typeof raw !== "object") return s;
    const g = (o, k, cap) => num(o && o[k], cap);
    s.bt.passed = flags(raw.bt && raw.bt.passed); s.bt.perfect = flags(raw.bt && raw.bt.perfect); s.bt.fast = flags(raw.bt && raw.bt.fast);
    s.bt.perfectRuns = g(raw.bt, "perfectRuns", CAPS.perfectRuns);
    s.ord.completed = g(raw.ord, "completed", CAPS.completed); s.ord.flawless = g(raw.ord, "flawless", CAPS.flawless);
    s.mow.completed = g(raw.mow, "completed", CAPS.completed); s.mow.flawless = g(raw.mow, "flawless", CAPS.flawless);
    s.blitz.best = g(raw.blitz, "best", CAPS.best); s.blitz.total = g(raw.blitz, "total", CAPS.total);
    s.slf.allFilled = g(raw.slf, "allFilled", CAPS.allFilled); s.slf.firstFull = g(raw.slf, "firstFull", CAPS.firstFull); s.slf.unique = g(raw.slf, "unique", CAPS.unique);
    for (const k of ["maxRank", "win3", "quantumWins", "quizmixWins", "quizmix3", "quizmix3Perfect", "meisterDraws"]) s.ttt[k] = g(raw.ttt, k, CAPS[k]);
    for (const [grp, keys] of [["chess", ["wins", "masterWins", "fast", "flawless", "games"]], ["four", ["wins", "hardWins", "quick", "diag", "online"]], ["mill", ["wins", "hardWins", "mills", "online"]], ["dame", ["wins", "hardWins", "online"]], ["daily", ["solved", "sudoku", "cw", "ws", "wv", "current", "longest"]], ["party", ["played", "wins"]], ["music", ["played", "correct"]], ["chem", ["found", "helps"]], ["vocab", ["learned", "exam", "talk", "stars3", "blitzBest"]], ["shop", ["buys", "slots", "boosters", "hearts"]]])
      for (const k of keys) s[grp][k] = g(raw[grp], k, CAPS[k]);
    if (raw.daily && typeof raw.daily.lastDate === "string" && /^\d{4}-\d{2}-\d{2}$/.test(raw.daily.lastDate)) s.daily.lastDate = raw.daily.lastDate;
    s.chem.found = Math.max(3, s.chem.found);
    s.gen.correct = g(raw.gen, "correct", CAPS.correct);
    s.sm.level = g(raw.sm, "level", CAPS.level);
    s.bio.topicsDone = g(raw.bio, "topicsDone", CAPS.topicsDone);
    s.bio.perfectCount = g(raw.bio, "perfectCount", CAPS.perfectCount);
    s.bio.sexualkundeUnlocked = (raw.bio && raw.bio.sexualkundeUnlocked) ? 1 : 0;
    s.streak.current = g(raw.streak, "current", CAPS.current);
    s.streak.longest = g(raw.streak, "longest", CAPS.longest);
    if (raw.streak && typeof raw.streak.lastDate === "string" && /^\d{4}-\d{2}-\d{2}$/.test(raw.streak.lastDate)) s.streak.lastDate = raw.streak.lastDate;
    // Freischalt-Zeitstempel bleiben (nur bekannte IDs, nur Zahlen); ob etwas frei ist, entscheidet evaluate()
    if (raw.unlocked && typeof raw.unlocked === "object") {
      for (const id of Object.keys(raw.unlocked)) { const t = Number(raw.unlocked[id]); if (BY_ID[id] && Number.isFinite(t) && t > 0) s.unlocked[id] = t; }
    }
    return s;
  }

  // Schaltet frei, was die Zaehler hergeben. Gibt die NEU freigeschalteten IDs zurueck.
  function evaluate(state, now) {
    const newly = [];
    for (const d of DEFS) {
      if (state.unlocked[d.id]) continue;
      const [cur, target] = d.progress(state);
      if (cur >= target) { state.unlocked[d.id] = now || Date.now(); newly.push(d.id); }
    }
    return newly;
  }

  // Bereits bestandene Klassen / erreichter Guertel aus dem bisherigen Profil uebernehmen
  function backfill(state, profile) {
    const klasse = Math.max(0, Math.min(KLASSEN, Math.floor(Number(profile && profile.klasse) || 0)));
    for (let i = 0; i < klasse; i++) state.bt.passed[i] = 1;
    state.ttt.maxRank = Math.max(state.ttt.maxRank, num(profile && profile.tttRank, CAPS.maxRank));
    state.sm.level = Math.max(state.sm.level, num(profile && profile.speedMathLevel, CAPS.level));
    // Bereits vor diesem Feature erspielter Biologie-Fortschritt zaehlt rueckwirkend.
    if (profile && profile.biologyDone && typeof profile.biologyDone === "object") {
      state.bio.topicsDone = Math.max(state.bio.topicsDone, Object.keys(profile.biologyDone).length);
    }
    if (profile && profile.biologyPerfect && typeof profile.biologyPerfect === "object") {
      state.bio.perfectCount = Math.max(state.bio.perfectCount, Object.keys(profile.biologyPerfect).length);
      if (Object.keys(profile.biologyPerfect).length >= 12) state.bio.sexualkundeUnlocked = 1;
    }
    return evaluate(state, Date.now());
  }

  // Ein Kalendertag (Europe/Berlin) weiter oder zurueck als "YYYY-MM-DD"-String,
  // ohne Zeitzonen-Stolperfallen (rechnet auf UTC-Mittag, damit Sommerzeit nie
  // den Tag verschiebt).
  function shiftDay(dateStr, delta) {
    const d = new Date(dateStr + "T12:00:00Z");
    d.setUTCDate(d.getUTCDate() + delta);
    return d.toISOString().slice(0, 10);
  }
  // Einmal pro Kalendertag aufrufen (z.B. beim ersten Spiel-Ereignis des Tages).
  // Ruft evaluate() nur dann auf, wenn sich wirklich etwas geaendert hat.
  function touchDaily(state, todayStr, now) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(todayStr || "")) return [];
    if (state.streak.lastDate === todayStr) return []; // heute schon gezaehlt
    if (state.streak.lastDate === shiftDay(todayStr, -1)) state.streak.current += 1; // nahtlos weiter
    else state.streak.current = 1; // erster Tag oder Luecke -> neu anfangen
    state.streak.lastDate = todayStr;
    state.streak.longest = Math.max(state.streak.longest, state.streak.current);
    return evaluate(state, now || Date.now());
  }

  // ------------------------------------------------------------------ Ereignisse
  // Gibt die IDs der dadurch NEU freigeschalteten Erfolge zurueck.
  function apply(state, evt, now) {
    if (!evt || typeof evt !== "object") return [];
    switch (evt.t) {
      case "gen": {
        state.gen.correct = Math.min(CAPS.correct, state.gen.correct + num(evt.n, 1e6));
        break;
      }
      case "braintest": { // Haupttest (20 Fragen), auch als Wiederholung
        const k = Math.floor(Number(evt.klasse));
        const correct = num(evt.correct, 1000), total = num(evt.total, 1000);
        if (!(k >= 0 && k < KLASSEN) || total < 1) break;
        const passed = correct >= Math.ceil(total * MAIN_TEST_PASS_PCT);
        const perfect = correct === total;
        if (passed) state.bt.passed[k] = 1;
        if (passed && perfect) state.bt.perfect[k] = 1;
        if (perfect) state.bt.perfectRuns = Math.min(CAPS.perfectRuns, state.bt.perfectRuns + 1);
        const secs = Number(evt.elapsedSec);
        if (passed && Number.isFinite(secs) && secs >= 0 && secs <= FAST_SECONDS) state.bt.fast[k] = 1;
        break;
      }
      case "ordering": case "mow": {
        const b = evt.t === "ordering" ? state.ord : state.mow;
        if (evt.finished) { b.completed++; if (evt.flawless) b.flawless++; }
        break;
      }
      case "blitz":
        state.blitz.best = Math.max(state.blitz.best, num(evt.total, CAPS.best));
        state.blitz.total = Math.min(CAPS.total, state.blitz.total + num(evt.total, CAPS.best));
        break;
      case "slf": {
        if (evt.allFilled) state.slf.allFilled++;
        if (evt.firstFull) state.slf.firstFull++;
        state.slf.unique = Math.min(CAPS.unique, state.slf.unique + num(evt.uniqueCount, 8));
        break;
      }
      case "ttt": { // nur bei GEWONNENEN Spielen aufrufen
        if (evt.mode === "quantum") state.ttt.quantumWins++;
        if (evt.mode === "quizmix") state.ttt.quizmixWins++;
        if (evt.in3) {
          state.ttt.win3++;
          if (evt.mode === "quizmix") { state.ttt.quizmix3++; if (evt.allCorrect) state.ttt.quizmix3Perfect++; }
        }
        break;
      }
      case "chess": { // nur bei GEWONNENEN Partien (games: bei jeder beendeten Partie)
        state.chess.games = Math.min(CAPS.games, state.chess.games + 1);
        if (evt.won) {
          state.chess.wins++;
          if (Number(evt.level) >= 4) state.chess.masterWins++;
          const mv = Number(evt.moves); if (mv > 0 && mv <= 20) state.chess.fast++;
          if (evt.lost === 0) state.chess.flawless++;
        }
        break;
      }
      case "four": { // nur bei gewonnenen Spielen
        const o = state.four; o.wins++;
        if (evt.hard) o.hardWins++;
        if (evt.online) o.online++;
        if (evt.diag) o.diag++;
        if (Number(evt.discs) === 4) o.quick++;
        break;
      }
      case "mill": { // won + mills (eigene geschlossene Muehlen dieser Partie)
        const o = state.mill; o.mills = Math.min(CAPS.mills, o.mills + num(evt.mills, 100));
        if (evt.won) { o.wins++; if (evt.hard) o.hardWins++; if (evt.online) o.online++; }
        break;
      }
      case "dame": {
        const o = state.dame; o.wins++;
        if (evt.hard) o.hardWins++;
        if (evt.online) o.online++;
        break;
      }
      case "party": { state.party.played = Math.min(CAPS.played, state.party.played + 1); if (evt.won) state.party.wins++; break; }
      case "music": { // Statistik: jede Musik-Runde zaehlt als gespielt
        state.music.played = Math.min(CAPS.played, state.music.played + 1);
        if (evt.correct) state.music.correct++;
        break;
      }
      case "daily": {
        const o = state.daily, ty = String(evt.type);
        o.solved++;
        if (["sudoku", "cw", "ws", "wv"].includes(ty)) o[ty]++;
        const day = evt.date;
        if (/^\d{4}-\d{2}-\d{2}$/.test(day || "") && o.lastDate !== day) {
          o.current = (o.lastDate === shiftDay(day, -1)) ? o.current + 1 : 1;
          o.lastDate = day; o.longest = Math.max(o.longest, o.current);
        }
        break;
      }
      case "tttRank": state.ttt.maxRank = Math.max(state.ttt.maxRank, num(evt.rank, CAPS.maxRank)); break;
      case "tttDraw": if (evt.meister) state.ttt.meisterDraws = Math.min(CAPS.meisterDraws, state.ttt.meisterDraws + 1); break;
      case "speedmath": state.sm.level = Math.max(state.sm.level, num(evt.level, CAPS.level)); break;
      case "biology": {
        // topicsDone/perfectCount sind GESAMTZAEHLER (aus profile.biologyDone/
        // biologyPerfect abgeleitet, nicht pro Ereignis +1) - deshalb Math.max
        // statt Addieren, sonst wuerden Wiederholungen doppelt zaehlen.
        state.bio.topicsDone = Math.max(state.bio.topicsDone, num(evt.topicsDone, CAPS.topicsDone));
        state.bio.perfectCount = Math.max(state.bio.perfectCount, num(evt.perfectCount, CAPS.perfectCount));
        if (evt.sexualkundeUnlocked) state.bio.sexualkundeUnlocked = 1;
        break;
      }
      case "chem": { // found = Gesamtzahl entdeckter Elemente (Max), help = Tipp gekauft
        if (evt.found != null) state.chem.found = Math.max(state.chem.found, num(evt.found, CAPS.found));
        if (evt.help) state.chem.helps = Math.min(CAPS.helps, state.chem.helps + 1);
        break;
      }
      case "vocab": { // Gesamtzaehler aus dem Lernstand (Max) + Blitz-Bestwert
        const o = state.vocab;
        for (const k of ["learned", "exam", "talk", "stars3", "blitzBest"]) if (evt[k] != null) o[k] = Math.max(o[k], num(evt[k], CAPS[k]));
        break;
      }
      case "shop": { // kind: slot | booster | heart | other
        const o = state.shop; o.buys = Math.min(CAPS.buys, o.buys + 1);
        if (evt.kind === "slot") o.slots++; else if (evt.kind === "booster") o.boosters++; else if (evt.kind === "heart") o.hearts++;
        break;
      }
      default: return [];
    }
    return evaluate(state, now);
  }

  // Server: gespeicherten und eingehenden Stand zusammenfuehren.
  // Zaehler = Maximum beider, Flags = ODER, "freigeschaltet" nur aus den Zaehlern.
  function merge(stored, incoming, now) {
    const a = normalize(stored), b = normalize(incoming), out = newState();
    for (let i = 0; i < KLASSEN; i++) { out.bt.passed[i] = a.bt.passed[i] | b.bt.passed[i]; out.bt.perfect[i] = a.bt.perfect[i] | b.bt.perfect[i]; out.bt.fast[i] = a.bt.fast[i] | b.bt.fast[i]; }
    const mx = (o, x, y) => { for (const k of Object.keys(o)) if (typeof o[k] === "number") o[k] = Math.max(x[k], y[k]); };
    mx(out.bt, a.bt, b.bt); mx(out.ord, a.ord, b.ord); mx(out.mow, a.mow, b.mow); mx(out.blitz, a.blitz, b.blitz);
    mx(out.slf, a.slf, b.slf); mx(out.ttt, a.ttt, b.ttt); mx(out.gen, a.gen, b.gen);
    mx(out.sm, a.sm, b.sm);
    for (const grp of ["chess", "four", "mill", "dame", "party", "music", "chem", "vocab", "shop"]) mx(out[grp], a[grp], b[grp]);
    mx(out.daily, a.daily, b.daily);
    { const n2 = (!a.daily.lastDate || (b.daily.lastDate && b.daily.lastDate >= a.daily.lastDate)) ? b.daily : a.daily; out.daily.current = n2.current; out.daily.lastDate = n2.lastDate; }
    out.bio.topicsDone = Math.max(a.bio.topicsDone, b.bio.topicsDone);
    out.bio.perfectCount = Math.max(a.bio.perfectCount, b.bio.perfectCount);
    out.bio.sexualkundeUnlocked = a.bio.sexualkundeUnlocked | b.bio.sexualkundeUnlocked;
    // Streak: laengste Serie ist das Maximum, "aktuell" + "letzter Tag" kommen vom
    // Stand mit dem SPAETEREN Datum (der andere ist veraltet und wuerde die Serie
    // sonst faelschlich abreissen lassen).
    out.streak.longest = Math.max(a.streak.longest, b.streak.longest);
    const newer = (!a.streak.lastDate || (b.streak.lastDate && b.streak.lastDate >= a.streak.lastDate)) ? b.streak : a.streak;
    out.streak.current = newer.current; out.streak.lastDate = newer.lastDate;
    // bereits gespeicherte Freischaltungen behalten (mit altem Zeitstempel); Neue nur aus den Zaehlern
    out.unlocked = Object.assign({}, a.unlocked);
    // Zeitstempel des Einsenders uebernehmen - aber NUR fuer Erfolge, die die Zaehler wirklich hergeben
    for (const id of Object.keys(b.unlocked)) {
      if (!out.unlocked[id]) { const [cur, target] = BY_ID[id].progress(out); if (cur >= target) out.unlocked[id] = b.unlocked[id]; }
    }
    evaluate(out, now || Date.now());
    return out;
  }

  // Anzeige-Hilfen
  function progressOf(state, id) { const d = BY_ID[id]; return d ? d.progress(state) : [0, 1]; }
  function summary(state) { const done = DEFS.filter(d => state.unlocked[d.id]).length; return { done, total: DEFS.length }; }

  return { DEFS, BY_ID, CATEGORIES, KLASSEN, FAST_SECONDS, newState, normalize, evaluate, backfill, apply, merge, touchDaily, progressOf, summary, getTitle, getDesc, getCategoryTitle };
});
